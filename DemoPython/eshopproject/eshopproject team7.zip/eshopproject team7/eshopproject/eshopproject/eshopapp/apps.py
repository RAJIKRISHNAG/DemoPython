from django.apps import AppConfig


class EshopappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eshopapp'
